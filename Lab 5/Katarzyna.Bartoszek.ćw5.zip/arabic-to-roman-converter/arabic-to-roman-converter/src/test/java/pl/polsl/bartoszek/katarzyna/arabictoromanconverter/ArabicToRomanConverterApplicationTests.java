package pl.polsl.bartoszek.katarzyna.arabictoromanconverter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArabicToRomanConverterApplicationTests {

	@Test
	void contextLoads() {
	}

}
